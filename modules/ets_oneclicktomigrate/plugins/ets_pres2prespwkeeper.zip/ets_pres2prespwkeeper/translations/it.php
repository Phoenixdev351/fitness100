<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_bd8b2bd2ae1bd102d9174fd0d753d8ca'] = ' Prestashop Password Keeper';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_e6d2a849d92cefd044479fbb80d067bb'] = 'Conserva le vecchie password quando eseguire la migrazione dei dati tra i siti Web Prestashop utilizzando Prestashop Migrator';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_923cc3fd014742fbc2a3dd76f2a7d8ca'] = '_COOKIE_KEY_ del sito di origine è richiesto';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_c888438d14855d7d96a2724ee9c306bd'] = 'Le impostazioni sono state aggiornate';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_51ac4bf63a0c6a9cefa7ba69b4154ef1'] = 'Ambientazione';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_97e6c933fc6cd2aa1da4a437bb9ea3f7'] = '_COOKIE_KEY_ del sito Web di origine';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_9c993291a1036a5ee376e8813d58c8e9'] = '_COOKIE_KEY_ viene fornito al termine della migrazione con Prestashop Migrator. È anche disponibile sul file delle impostazioni (settings.inc.php) del sito Web di origine.';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>form_fa535ffb25e1fd20341652f9be21e06e'] = 'Configurare';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>form_f25b7a4db1d87afa1d07b8c2355acef1'] = '_COOKIE_KEY_ del sito Web di origine';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>form_b17f3f4dcf653a5776792498a9b44d6a'] = 'Aggiorna impostazioni';

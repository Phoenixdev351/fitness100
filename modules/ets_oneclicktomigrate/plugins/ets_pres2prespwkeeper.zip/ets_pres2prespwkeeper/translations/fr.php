<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_bd8b2bd2ae1bd102d9174fd0d753d8ca'] = 'Prestashop Password Keeper';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_e6d2a849d92cefd044479fbb80d067bb'] = 'Conservez vos anciens mots de passe lorsque vous migrez des données entre des sites Web Prestashop à l\'aide de Prestashop Migrator';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_923cc3fd014742fbc2a3dd76f2a7d8ca'] = '_COOKIE_KEY_ du site source est obligatoire';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_51ac4bf63a0c6a9cefa7ba69b4154ef1'] = 'Réglage';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_97e6c933fc6cd2aa1da4a437bb9ea3f7'] = '_COOKIE_KEY_ du site source';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_9c993291a1036a5ee376e8813d58c8e9'] = '_COOKIE_KEY_ est fourni lorsque vous terminez la migration à l\'aide de Prestashop Migrator. Il est également disponible dans le fichier de paramètres (settings.inc.php) du site Web source.';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>form_fa535ffb25e1fd20341652f9be21e06e'] = 'Configurer';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>form_f25b7a4db1d87afa1d07b8c2355acef1'] = '_COOKIE_KEY_ du site source';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>form_b17f3f4dcf653a5776792498a9b44d6a'] = 'Mettre à jour les paramètres';

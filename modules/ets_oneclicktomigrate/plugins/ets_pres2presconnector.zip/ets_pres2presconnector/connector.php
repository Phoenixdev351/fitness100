<?php
/**
 * 2007-2018 ETS-Soft
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 wesite only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please contact us for extra customization service at an affordable price
 *
 * @author ETS-Soft <etssoft.jsc@gmail.com>
 * @copyright  2007-2018 ETS-Soft
 * @license    Valid for 1 website (or project) for each purchase of license
 *  International Registered Trademark & Property of ETS-Soft
 */

if (!defined('_PS_ADMIN_DIR_')) {
    define('_PS_ADMIN_DIR_', getcwd());
}
if (!defined('PS_INSTALLATION_IN_PROGRESS')) {
    define('PS_INSTALLATION_IN_PROGRESS', 1);
}
@ini_set('display_errors', 'off');
@ini_set('memory_limit', '1600M');
@ini_set('max_execution_time', '300');

include(_PS_ADMIN_DIR_ . '/../../config/config.inc.php');
if (version_compare(_PS_VERSION_, '1.5', '<')) {
    global $cookie, $link, $useSSL;
    $cookie = new Cookie('ps', '', time() + (((int)Configuration::get('PS_COOKIE_LIFETIME_FO') > 0 ? (int)Configuration::get('PS_COOKIE_LIFETIME_FO') : 1) * 3600));
    $link = new Link();
    if (Tools::usingSecureMode())
        $useSSL = true;
} else
    include(dirname(__FILE__) . '/ajax.init.php');

$ets_pres2presconnector = Module::getInstanceByName('ets_pres2presconnector');

if (!Configuration::get('ETS_PRES2PRES_CONNECTOR')) {
    die('Direct migration is disabled');
}
if (Tools::isSubmit('presconnector') && Tools::isSubmit('ajaxPercentageExport') && Tools::getValue('ajaxPercentageExport')) {
    $ets_pres2presconnector->ajaxPercentageExport();
}
if (Tools::isSubmit('presconnector') && Tools::getValue('pres2prestocken') == Configuration::get('ETS_PRES2PRES_TOCKEN')) {
    $ets_pres2presconnector->processExport();
}
if (Tools::isSubmit('ajax_percentage_export')) {
    $ets_pres2presconnector->ajaxPercentageExport();
}
if (Tools::isSubmit('btnSubmitDownload')) {
    Configuration::updateValue('ETS_PRES2PRES_ORDER_FROM', Tools::getValue('ETS_PRES2PRES_ORDER_FROM'));
    Configuration::updateValue('ETS_PRES2PRES_ORDER_TO', Tools::getValue('ETS_PRES2PRES_ORDER_TO'));
    $ets_pres2presconnector->processExport();
}
die('Secure access token is missing or not valid');
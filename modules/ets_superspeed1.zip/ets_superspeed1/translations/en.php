<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_superspeed}prestashop>ets_superspeed_4ea94ceb3cc5718c67651bed5c52a973'] = 'Number of module hooks have execution time greater than 1000 ms';

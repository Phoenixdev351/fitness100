<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class SequracheckoutPreQualifier extends SequraPreQualifier
{
    protected static $MODULE_NAME = 'sequracheckout';
    protected static $SERVICE_COMPATIBLE = true;

    public static function canDisplayInfo($price = null)
    {
        //For this plugin widgets are added on page footer (footer.tpl)
        return false;
    }

    public static function isPriceWithinMethodRange($method, $price, $check_min = true)
    {
        $max = $method['max_amount']/100;
        $min = $method['min_amount']/100;
        $too_much = is_numeric($max) && $max > 0 && $price > $max;
        $too_low = (is_numeric($min) && $min > 0 && $price < $min) && $check_min;

        return !$too_much && !$too_low;
    }
}

<?php
header("Location: ../");

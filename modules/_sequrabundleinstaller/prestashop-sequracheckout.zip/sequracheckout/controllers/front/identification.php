<?php
require_once(_PS_MODULE_DIR_ . SEQURA_CORE . '/controllers/front/identification.php');
class SequrainvoiceIdentificationModuleFrontController extends SequrapaymentIdentificationModuleFrontController {}

<?php
require_once(_PS_MODULE_DIR_ . SEQURA_CORE . '/controllers/front/getidentificationform.php');
class SequracheckoutGetIdentificationFormModuleFrontController extends SequrapaymentGetIdentificationFormModuleFrontController {}

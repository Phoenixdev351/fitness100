<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class SequraFee
{
    public function __construct($module)
    {
        $this->module = $module;
    }

    public function withTax()
    {
        $this->init();
        return $this->_with_tax;
    }

    public function withoutTax()
    {
        $this->init();
        return $this->_without_tax;
    }

    public function taxRate()
    {
        $this->init();
        return $this->_tax_rate;
    }

    public function displayPriceWithTax()
    {
        return $this->withTax() ? Tools::displayPrice($this->withTax() / 100.0) : '';
    }

    public function productId()
    {
        return Configuration::get('SEQURA_FEE');
    }

    public function asOrderItem()
    {
        $this->init();
        return array(
            'type' => 'invoice_fee',
            'total_with_tax' => $this->withTax(),
            'tax_rate' => 0,//$this->taxRate(),
            'total_without_tax' => $this->withTax(),//$this->withoutTax(),
            'reference' => $this->_product->reference,
        );
    }

    private $_inited = false;
    // all values are integers
    private $_with_tax = 0;
    private $_without_tax = 0;
    private $_tax_rate = 0;
    private $_product = null;

    private function init()
    {
        if (!isset($this->module->uses_fee) || !$this->module->uses_fee) {
            return;
        }
        if ($this->_inited) {
            return;
        }
        $this->_inited = true;
        $product = new Product(Configuration::get('SEQURA_FEE'));
        if (!$product->id) {
            return;
        }

        // Decimal prices with high precision, useful for deriving tax
        $with_tax = $product->getPrice(true);
        $without_tax = $product->getPrice(false);
        if ($without_tax != 0) {
            $tax_rate = ($with_tax / $without_tax) - 1; // 0.21
            $this->_tax_rate = intval(round(100 * 100 * $tax_rate));
        }
        $this->_with_tax = SequraTools::integerPrice($with_tax);
        $this->_without_tax = SequraTools::integerPrice($without_tax);
        $this->_product = $product;
    }
}
